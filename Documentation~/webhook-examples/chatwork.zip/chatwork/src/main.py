#!/usr/bin/env python
# -*- coding: utf-8 -*-

import os

from flask import Flask
from flask import abort, request
from flask_httpauth import HTTPBasicAuth
from werkzeug.security import generate_password_hash, check_password_hash
import requests


app = Flask(__name__)
app.config['ROOM_ID'] = os.environ.get('ROOM_ID')
app.config['API_TOKEN'] = os.environ.get('API_TOKEN')

auth = HTTPBasicAuth()
users = {
    os.environ.get('BACKTRACE_USER'): generate_password_hash(os.environ.get('BACKTRACE_PSWD')),
}


@auth.verify_password
def verify_password(username, password):
    if username in users and \
            check_password_hash(users.get(username), password):
        return username


def post_chatwork(msg):
    url = f"https://api.chatwork.com/v2/rooms/{app.config['ROOM_ID']}/messages"
    headers = {'X-ChatWorkToken': app.config['API_TOKEN']}
    data = {'body': msg,
            'self_unread': 0}
    post = requests.post(url, headers=headers, data=data)
    return post.status_code


@app.route('/', methods=['POST'])
@auth.login_required
def main():
    msg = f"エラー発生中！至急Backtraceで確認してください: {request.json['group_url']}"
    status_code = post_chatwork(msg)
    if status_code == 200:
        return 'Success!'
    else:
        abort(500)
