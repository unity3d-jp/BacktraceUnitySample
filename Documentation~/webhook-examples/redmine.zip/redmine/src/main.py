#!/usr/bin/env python
# -*- coding: utf-8 -*-

import os

from flask import Flask
from flask import abort, request
from flask_httpauth import HTTPBasicAuth
from werkzeug.security import generate_password_hash, check_password_hash
from redminelib import Redmine


app = Flask(__name__)
app.config['REDMINE_HOST'] = os.environ.get('REDMINE_HOST')
app.config['REDMINE_USER'] = os.environ.get('REDMINE_USER')
app.config['REDMINE_PSWD'] = os.environ.get('REDMINE_PSWD')
app.config['REDMINE_PRJ'] = os.environ.get('REDMINE_PRJ')
auth = HTTPBasicAuth()
users = {
    os.environ.get('BACKTRACE_USER'): generate_password_hash(os.environ.get('BACKTRACE_PSWD')),
}


@auth.verify_password
def verify_password(username, password):
    if username in users and \
            check_password_hash(users.get(username), password):
        return username


def post_redmine(issue_subject, description):
    """
    create issue on redmine.
    """
    redmine = Redmine(app.config['REDMINE_HOST'],
                      username=app.config['REDMINE_USER'],
                      password=app.config['REDMINE_PSWD'])

    redmine.issue.create(
        project_id=app.config['REDMINE_PRJ'],
        subject=issue_subject,
        description=description
    )


@app.route('/', methods=['POST'])
@auth.login_required
def main():
    issue_subject = f"{request.json['application']}: {request.json['guids']}"
    description = f"{request.json['group_url']}"
    try:
        post_redmine(issue_subject, description)
    except Exception as e:
        abort(500)
    return 'Success!'
